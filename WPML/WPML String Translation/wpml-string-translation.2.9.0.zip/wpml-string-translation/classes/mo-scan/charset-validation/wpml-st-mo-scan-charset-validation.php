<?php

interface WPML_ST_MO_Scan_Charset_Validation {
	/**
	 * @return bool
	 */
	public function is_valid();
}
