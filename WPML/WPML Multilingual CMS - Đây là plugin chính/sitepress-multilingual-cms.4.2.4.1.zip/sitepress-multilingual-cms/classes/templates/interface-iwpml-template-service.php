<?php

/**
 * @author OnTheGo Systems
 */
interface IWPML_Template_Service {
	public function show( $model, $template );
}
