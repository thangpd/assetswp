<?php
/**
 * Template hooks for Header
 */
add_action( 'electro_header_icons', 'electro_header_mini_cart_icon', 90 );
add_action( 'electro_header_icons', 'electro_header_user_account',   80 );