jQuery(document).ready(function () {
	jQuery(function () {
		jQuery("#tabs-course").tabs().fadeIn(300);
	});
});