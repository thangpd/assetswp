<?php if (!defined('FW')) die('Forbidden'); ?>

<p>You should never have seen this, because the shortcode ought to be disabled.</p>
