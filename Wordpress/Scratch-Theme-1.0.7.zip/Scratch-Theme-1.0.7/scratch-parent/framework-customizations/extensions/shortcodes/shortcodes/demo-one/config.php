<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Demo 1', 'unyson' ),
		'description' => __( 'Demo of a simple shortcode without options', 'unyson' ),
		'tab'         => __( 'Content Elements', 'fw' ),
	)
);