This is an example of a shortcode integrated with the page builder. 

The example illustrates how to create a shortcode with options and use them in the view file. 

The shortcode's options and view file are [overwritten](https://github.com/ThemeFuse/Scratch-Theme/tree/master/scratch-child/framework-customizations/extensions/shortcodes/shortcodes/demo-two) in the child theme, so if you activate the scratch child theme those files will be loaded instead of the ones from the parent theme.