This is an example of a shortcode integrated with the page builder.

The shortcode provides a custom class, that overrides the default behavior.