This is an example of a shortcode integrated with the page builder and overwriting.

The options and view files overwrite the ones from the [parent theme](https://github.com/ThemeFuse/Scratch-Theme/tree/master/scratch-parent/framework-customizations/extensions/shortcodes/shortcodes/demo-two).
